# @babel/helper-skip-transparent-expression-wrappers

> Helper which skips types and parentheses

## Install

Using npm:

```sh
npm install --save-dev @babel/helper-skip-transparent-expression-wrappers
```

or using yarn:

```sh
yarn add @babel/helper-skip-transparent-expression-wrappers --dev
```
