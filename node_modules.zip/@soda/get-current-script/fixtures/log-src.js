document.getElementById('app').textContent = window.getCurrentScript().src
