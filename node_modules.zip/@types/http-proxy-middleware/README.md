# Installation
> `npm install --save @types/http-proxy-middleware`

# Summary
This package contains type definitions for http-proxy-middleware (https://github.com/chimurai/http-proxy-middleware).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/http-proxy-middleware

Additional Details
 * Last updated: Mon, 19 Aug 2019 00:51:16 GMT
 * Dependencies: @types/connect, @types/http-proxy, @types/node
 * Global values: none

# Credits
These definitions were written by Zebulon McCorkle <https://github.com/zebMcCorkle>, and BendingBender <https://github.com/BendingBender>.
