# Installation
> `npm install --save @types/connect-history-api-fallback`

# Summary
This package contains type definitions for connect-history-api-fallback (https://github.com/bripkens/connect-history-api-fallback#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/connect-history-api-fallback

Additional Details
 * Last updated: Mon, 19 Aug 2019 00:51:09 GMT
 * Dependencies: @types/express-serve-static-core, @types/node
 * Global values: none

# Credits
These definitions were written by Douglas Duteil <https://github.com/douglasduteil>.
